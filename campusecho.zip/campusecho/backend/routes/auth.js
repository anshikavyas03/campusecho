/**
 * Authentication Routes
 * POST /api/auth/register - Create new account
 * POST /api/auth/login    - Login and receive JWT
 * GET  /api/auth/me       - Get current user profile
 */

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { authMiddleware, JWT_SECRET } = require('../middleware/auth');

// ========================
// REGISTER
// ========================
/**
 * POST /api/auth/register
 * Body: { name, email, password, department? }
 *
 * Response (201):
 * { message: "Registration successful", token, user: { id, name, email, role } }
 */
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, department } = req.body;

    // --- Input validation ---
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    // --- Check for existing user ---
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    // --- Create user (password is hashed via pre-save hook in User model) ---
    const user = new User({ name, email, department: department || 'General' });

    // Set admin role if email contains 'admin' (demo purpose — use env config in production)
    if (email.includes('admin')) user.role = 'admin';

    user.password = password; // Will be hashed by model hook
    await user.save();

    // --- Generate JWT token ---
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      message: 'Registration successful! Welcome to CampusEcho.',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department
      }
    });

  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(e => e.message);
      return res.status(400).json({ error: messages.join(' ') });
    }
    console.error('Register error:', err);
    res.status(500).json({ error: 'Server error during registration.' });
  }
});

// ========================
// LOGIN
// ========================
/**
 * POST /api/auth/login
 * Body: { email, password }
 *
 * Response (200):
 * { message: "Login successful", token, user: { id, name, email, role } }
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // --- Input validation ---
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    // --- Find user by email ---
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // --- Verify password ---
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // --- Generate JWT ---
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      message: `Welcome back, ${user.name}!`,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department
      }
    });

  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// ========================
// GET CURRENT USER
// ========================
/**
 * GET /api/auth/me
 * Headers: Authorization: Bearer <token>
 */
router.get('/me', authMiddleware, async (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
